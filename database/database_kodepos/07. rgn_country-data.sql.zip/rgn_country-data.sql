
--
-- Dumping data for table `rgn_country`
--

INSERT INTO `rgn_countries` (`id`, `name`, `abbreviation`) VALUES
(1, 'Indonesia', 'ina');
